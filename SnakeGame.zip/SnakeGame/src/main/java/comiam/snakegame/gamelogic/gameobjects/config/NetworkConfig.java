package comiam.snakegame.gamelogic.gameobjects.config;

public interface NetworkConfig
{
    int getPingDelayMs();
    int getNodeTimeoutMs();
}
