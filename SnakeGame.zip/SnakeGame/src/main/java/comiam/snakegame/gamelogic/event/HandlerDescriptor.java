package comiam.snakegame.gamelogic.event;

@FunctionalInterface
public interface HandlerDescriptor
{
    void remove();
}
