package comiam.snakegame.gamelogic.gameobjects.config;

public class InvalidConfigException extends Exception
{
    public InvalidConfigException(final String message)
    {
        super(message);
    }
}
