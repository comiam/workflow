package comiam.snakegame.gamelogic.gamefield;

public interface Coordinates
{
    int getX();
    int getY();
}
