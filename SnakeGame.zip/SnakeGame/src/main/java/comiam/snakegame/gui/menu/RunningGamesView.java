package comiam.snakegame.gui.menu;

@FunctionalInterface
public interface RunningGamesView
{
    void updateView();
}
