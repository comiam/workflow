package comiam.snakegame.util.unsafe;

@FunctionalInterface
public interface UnsafeRunnable
{
    void run() throws Exception;
}
